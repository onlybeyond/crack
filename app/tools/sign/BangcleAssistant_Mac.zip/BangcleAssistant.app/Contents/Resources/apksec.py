# -*- coding: utf-8 -*-
#!/usr/bin/python

#########################################################################
#
# Author : Choopan RATTANAPOKA
#
# Description : Main ABC [Yet Another Bittorrent Client] python script.
#               you can run from source code by using
#               >python abc.py
#               need Python, WxPython in order to run from source code.
###########################################,,         ##############################
import sys, locale
reload(sys)
sys.setdefaultencoding('utf-8')
import wx
wx.SetDefaultPyEncoding('utf-8')
import os
import ctypes

from abcengine import send_http
#import hotshot
import controller
from threading import Thread
from traceback import print_exc
from cStringIO import StringIO
from interconn import ServerListener, ClientPassParam
#from launchmanycore import LaunchMany
from ABC.Toolbars.toolbars import ABCBottomBar2, ABCStatusBar, ABCMenuBar, ABCToolBar
from ABC.GUI.menu import ABCMenu
from ABC.Scheduler.scheduler import ABCScheduler
from ABC.GUI.tree import TreePanel,ABCTree
from Dialogs.aboutme import NoticeDialog
from regedit import IfLanguageIsChinese
import controller
from log import logger
#from webservice import WebListener


if (sys.platform == 'win32'):
    from Dialogs.regdialog import RegCheckDialog

from ABC.GUI.list import ManagedList
from Utility.utility import Utility
from Utility.constants import * #IGNORE:W0611
import multiprocessing 

appObject1 = None   
reload(sys)  
#sys.setdefaultencoding('ascii') #gb2312,utf-8utf-8  
##print sys.getdefaultencoding()
################################################################
#
# Class: FileDropTarget
#
# To enable drag and drop for ABC list in main menu
#
################################################################
class FileDropTarget(wx.FileDropTarget): 
    def __init__(self, utility):
        # Initialize the wsFileDropTarget Object 
        wx.FileDropTarget.__init__(self) 
        # Store the Object Reference for dropped files 
        self.utility = utility
      
    def OnDropFiles(self, x, y, filenames):
        for filename in filenames:
            self.utility.queue.addtorrents.AddTorrentFromFile(filename)
        return True


##############################################################
#
# Class : ABCList
#
# ABC List class that contains the torrent list
#
############################################################## 
class ABCList(ManagedList):
    def __init__(self, parent):
        style =  wx.LC_REPORT | wx.BORDER_NONE
        
        #|wx.LC_VRULES
        #|wx.CLIP_CHILDREN
        
        prefix = 'column'
        minid = 4
        maxid = 13
        exclude = []
        


        ManagedList.__init__(self, parent, style, prefix, minid, maxid, exclude, [])
        
        dragdroplist = FileDropTarget(self.utility)
        self.SetDropTarget(dragdroplist)
        import platform
        if platform.system()=='Darwin':
                self.SetFont(wx.Font(12, wx.SWISS, wx.NORMAL,wx.NORMAL))
        else:
                self.SetFont(wx.Font(10, wx.SWISS, wx.NORMAL,wx.NORMAL))
        self.lastcolumnsorted = -1
        self.reversesort = False

        self.Bind(wx.EVT_KEY_DOWN, self.OnKeyDown)
        self.Bind(wx.EVT_LIST_COL_CLICK, self.OnColLeftClick)

        #self.Bind(wx.EVT_LIST_ITEM_RIGHT_CLICK, self.OnRightClick)
        
        # Bring up advanced details on left double click
        self.Bind(wx.EVT_LEFT_DCLICK, self.OnLeftDClick)
        
        # Bring up local settings on middle double click
        self.Bind(wx.EVT_MIDDLE_DCLICK, self.utility.actions[ACTION_LOCALUPLOAD].action)
        self.Bind(wx.EVT_LIST_ITEM_SELECTED, self.OnItemSelected)

    # Do thing when keys are pressed down
    def OnKeyDown(self, event):
        keycode = event.GetKeyCode()
        if event.CmdDown():
            if keycode == ord('a') or keycode == ord('A'):
                # Select all files (CTRL-A)
                self.selectAll()
            elif keycode == ord('x') or keycode == ord('X'):
                # Invert file selection (CTRL-X)
                self.invertSelection()
        elif keycode == wx.WXK_RETURN or keycode == wx.WXK_NUMPAD_ENTER:
            # Open advanced details (Enter)
            self.utility.actions[ACTION_DETAILS].action()
        elif keycode == wx.WXK_SPACE:
            # Open local settings (Space)
            self.utility.actions[ACTION_LOCALUPLOAD].action()
        elif keycode == 399:
            # Open right-click menu (windows menu key)
            self.OnItemSelected()
        
        event.Skip()
        
    def OnColLeftClick(self, event):
        rank = event.GetColumn()
        colid = self.columns.getIDfromRank(rank)
        if colid == self.lastcolumnsorted:
            self.reversesort = not self.reversesort
        else:
            self.reversesort = False
        self.lastcolumnsorted = colid
        
        self.utility.queue.sortList(colid, self.reversesort)       
        
    def selectAll(self):
        self.updateSelected(select = range(0, self.GetItemCount()))

    def updateSelected(self, unselect = None, select = None):
        if unselect is not None:
            for index in unselect:
                self.SetItemState(index, 0, wx.LIST_STATE_SELECTED)
        if select is not None:
            for index in select:
                self.Select(index)
        self.SetFocus()

    def getTorrentSelected(self, firstitemonly = False, reverse = False):
        queue = self.utility.queue
        
        torrentselected = []
        for index in self.getSelected(firstitemonly, reverse):
            ABCTorrentTemp = ctypes.cast(self.GetItemData(index),ctypes.py_object).value
            
            #ABCTorrentTemp = queue.getABCTorrent(index = index)
            if ABCTorrentTemp is not None:
                torrentselected.append(ABCTorrentTemp)
        return torrentselected

    def OnRightClick(self, event = None):
        ##print 'wwm:OnItemSelected'
        selected = self.getTorrentSelected()
        if not selected:
            return

        popupmenu = ABCMenu(self.utility, 'menu_listrightclick')

        # Popup the menu.  If an item is selected then its handler
        # will be called before PopupMenu returns.
        if event is None:
            # use the position of the first selected item (key event)
            ABCTorrentTemp = selected[0]
            position = self.GetItemPosition(ABCTorrentTemp.listindex)
        else:
            # use the cursor position (mouse event)
            position = event.GetPosition()
        
        self.PopupMenu(popupmenu, position)

    def OnLeftDClick(self, event):
        event.Skip()
        self.utility.actions[ACTION_DETAILS].action()


    def OnItemSelected(self, event):
        currentItem = event.m_itemIndex
        torrent = ctypes.cast(self.GetItemData(currentItem),ctypes.py_object).value
        
        torrent.flushActions()

        event.Skip()

##############################################################
#
# Class : ABCPanel
#
# Main ABC Panel class
#
############################################################## 
class ABCPanel(wx.Panel):
    def __init__(self, parent):
        style = wx.CLIP_CHILDREN
        wx.Panel.__init__(self, parent, -1, style = style)

        #Debug Output.
        sys.stdout.write('Preparing GUI.\n');
        self.utility    = parent.utility
        self.utility.window = self
        self.queue = self.utility.queue
               
        # List of deleting torrents events that occur when the RateManager is active
        # Such events are processed after the RateManager finishes
        # postponedevents is a list of tupples : each tupple contains the method of ABCPanel to be called to
        # deal with the event and the event.
        self.postponedevents = []

        #Manual Bittorrent Adding UI
        ##############################
        colSizer = wx.BoxSizer(wx.VERTICAL)

        # List Control Display UI
        ###############################
        self.list = ABCList(self)
        self.utility.list = self.list
        import platform
        if platform.system()=='Darwin':
            #colSizer.Add(self.list, 1, wx.RIGHT, 35)
            colSizer.Add(self.list, 1, wx.EXPAND|wx.ALL, 2)
        else:
            colSizer.Add(self.list, 1, wx.EXPAND|wx.ALL, 2)

        #self.utility.bottomline2 = ABCBottomBar2(self)

        #colSizer.Add(self.utility.bottomline2, 0, wx.ALL|wx.EXPAND, 3)
        
        self.SetSizer(colSizer)
        self.SetAutoLayout(True)
        
        self.list.SetFocus()
        
    def getSelectedList(self, event = None):
        return self.list

    ######################################
    # Update ABC on-the-fly
    ######################################
    def updateColumns(self, force = False):
        # Update display in column for inactive torrent
        for ABCTorrentTemp in self.utility.torrents["all"]:
            ABCTorrentTemp.updateColumns(force = force) 
 
   
##############################################################
#
# Class : ABCTaskBarIcon
#
# Task Bar Icon
#
############################################################## 
class ABCTaskBarIcon(wx.TaskBarIcon):
    def __init__(self, parent):
        wx.TaskBarIcon.__init__(self)
        
        self.utility = parent.utility
        
        self.TBMENU_RESTORE = wx.NewId()

        # setup a taskbar icon, and catch some events from it
        self.Bind(wx.EVT_TASKBAR_LEFT_DCLICK, parent.onTaskBarActivate)
        self.Bind(wx.EVT_MENU, parent.onTaskBarActivate, id = self.TBMENU_RESTORE)
               
        self.updateIcon()
        
    def updateIcon(self):
        remove = True
        
        mintray = self.utility.config.Read('mintray', "int")
        if (mintray >= 2) or ((mintray >= 1) and self.utility.frame.IsIconized()):
            remove = False
        
        if remove and self.IsIconInstalled():
            self.RemoveIcon()
        elif not remove and not self.IsIconInstalled():
            self.SetIcon(self.utility.icon, "ABC")
        
    def CreatePopupMenu(self):        
        menu = wx.Menu()
        
        self.utility.actions[ACTION_STOPALL].addToMenu(menu, bindto = self)
        self.utility.actions[ACTION_UNSTOPALL].addToMenu(menu, bindto = self)
        menu.AppendSeparator()
        menu.Append(self.TBMENU_RESTORE, self.utility.lang.get('showabcwindow'))
        
        self.utility.actions[ACTION_EXIT].addToMenu(menu, bindto = self)
        return menu


##############################################################
#
# Class : ABCFrame
#
# Main ABC Frame class that contains menu and menu bar management
# and contains ABCPanel
#
############################################################## 
class ABCFrame(wx.Frame):
    def __init__(self, ID, params, utility):
        self.utility = utility
        self.utility.frame = self
        self.utility.showframe = self
        title = self.utility.lang.get('title') + \
                " " + VERSION_NAME
                #+ \self.utility.lang.get('version')
        
        # Get window size and position from config file
        size, position = self.getWindowSettings()
        style = wx.DEFAULT_FRAME_STYLE | wx.CLIP_CHILDREN
        wx.Frame.__init__(self, None, ID, title, position, size=(900,600), style = style)
        
        self.tbicon = None

        self.abc_sb = ABCStatusBar(self)
        self.SetStatusBar(self.abc_sb)

        try:
            self.SetIcon(self.utility.icon)
        except:
            pass
        

        # Don't update GUI as often when iconized
        self.GUIupdate = True

        # Start the scheduler before creating the ListCtrl
        self.splitter = wx.SplitterWindow(self, -1 , style = wx.SP_NOBORDER | wx.SP_LIVE_UPDATE)
        self.splitter.utility = self.utility
        self.window = ABCPanel(self.splitter)

        self.tree = TreePanel(self.splitter)
        #ABCTree(self.splitter)


#        self.splitter.SetAutoLayout(True)
#        self.splitter.Fit()                

        self.splitter.SetMinimumPaneSize(20)
        point = wx.Point(0,35)
        self.splitter.SplitVertically(self.tree, self.window, 200)

#        self.window = ABCPanel(self)

        # Menu Options
        ############################
        menuBar = ABCMenuBar(self)
        self.SetMenuBar(menuBar)
        
        import platform
        if platform.system()=='Darwin':
            self.tb = ABCToolBar(self)
            #self.SetToolBar(self.tb)
            self.tb.Realize()
            
            sizer = wx.BoxSizer(wx.VERTICAL)
            sizer.Add(self.tb, proportion=0, flag=wx.EXPAND|wx.TOP)
           
            sizer.Add(self.splitter, proportion=1, flag=wx.EXPAND|wx.ALL)
            
            self.SetSizer(sizer)
            #self.toolbar = self.CreateToolBar() 
            #self.toolbar = ABCToolBar(self)
            #size = wx.Size(3000,35)
            #self.toolbar.SetSize(size)
            #self.SetToolBar(self.tb)
        else:
            self.tb = ABCToolBar(self)
            self.SetToolBar(self.tb)
        
        
#         self.tb = ABCToolBar(self)
#         self.SetToolBar(self.tb)
        
            

        # Menu Events 
        ############################

        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow)
#        self.Bind(wx.EVT_MENU, self.OnMenuExit, id = wx.ID_CLOSE)

        # leaving here for the time being:
        # wxMSW apparently sends the event to the App object rather than
        # the top-level Frame, but there seemed to be some possibility of
        # change
        self.Bind(wx.EVT_QUERY_END_SESSION, self.OnCloseWindow)
        self.Bind(wx.EVT_END_SESSION, self.OnCloseWindow)
        
        try:
            self.tbicon = ABCTaskBarIcon(self)
        except:
            pass
        #self.Bind(wx.EVT_ICONIZE, self.onIconify)
        #self.Bind(wx.EVT_SET_FOCUS, self.onFocus)

        # Check webservice for autostart webservice
        #######################################################
        #WebListener(self.utility)
        #if self.utility.webconfig.Read("webautostart", "boolean"):
            #self.utility.webserver.start()
            
        # Start up the controller
        #self.utility.controller = LaunchMany(self.utility)
        #self.utility.controller.start()

        self.utility.queue.postInitTasks()
        self.tree.tree.SelectItem(self.tree.tree.alltask)
        # Start single instance server listenner
        ############################################
        self.serverlistener = ServerListener(self.utility)
        self.serverthread   = Thread(target = self.serverlistener.start)
        self.serverthread.setDaemon(True)
        self.serverthread.start()

        #if server start with params run it
        #####################################
        if params[0] != "":
            ClientPassParam(params[0])

        sys.stdout.write('GUI Complete.\n')
        self.Show(True)
        
        self.utility.tree.refreshTreeNums(0,0)
        
        
    def onFocus(self, event = None):
        if event is not None:
            event.Skip()
        self.window.getSelectedList(event).SetFocus()
        
    def setGUIupdate(self, update):
        oldval = self.GUIupdate
        self.GUIupdate = update
        
        if self.GUIupdate and not oldval:
            # Force an update of all torrents
            for torrent in self.utility.torrents["all"]:
                torrent.updateColumns()
                torrent.updateColor()

    #######################################
    # minimize to tray bar control
    #######################################
    def onTaskBarActivate(self, event = None):
        self.Iconize(False)
        self.Show(True)
        self.Raise()
        
        if self.tbicon is not None:
            self.tbicon.updateIcon()

        self.window.list.SetFocus()

        # Resume updating GUI
        self.setGUIupdate(True)

    def onIconify(self, event = None):
        if (self.utility.config.Read('mintray', "int") > 0
            and self.tbicon is not None):
            self.tbicon.updateIcon()
            self.Show(False)
        
        if event is not None:
            event.Skip()

        # Don't update GUI while minimized
        self.setGUIupdate(not self.GUIupdate)
        
    def getWindowSettings(self):
        width = self.utility.config.Read("window_width")
        height = self.utility.config.Read("window_height")
        try:
            size = wx.Size(int(width), int(height))
        except:
            size = wx.Size(950, 540)
        
        x = self.utility.config.Read("window_x")
        y = self.utility.config.Read("window_y")
        if (x == "" or y == ""):
            position = wx.DefaultPosition
        else:
            position = wx.Point(int(x), int(y))
            
        return size, position     
    
        
    def saveWindowSettings(self):
        width, height = self.GetSizeTuple()
        x, y = self.GetPositionTuple()
        self.utility.config.Write("window_width", width)
        self.utility.config.Write("window_height", height)
        self.utility.config.Write("window_x", x)
        self.utility.config.Write("window_y", y)

        self.utility.config.Flush()
       
    ##################################
    # Close Program
    ##################################
    
    def DestorySelf(self):
        self.Destroy()
    
    def OnCloseWindow(self, event = None):
        # Don't do anything if the event gets called twice for some reason
        if self.utility.abcquitting:
            return
        
        if event is not None:
            try:
                if event.CanVeto() and self.utility.config.Read('confirmonclose', "boolean"):
                    dialog = wx.MessageDialog(None, self.utility.lang.get('confirmmsg'), self.utility.lang.get('confirm'), wx.YES_NO)
                    dialog.SetYesNoLabels(self.utility.lang.get('ipset_btnOK'),self.utility.lang.get('ipset_btnCancel'))    
                    result = dialog.ShowModal()
                    dialog.Destroy()
                    ##print 'current_process: ', multiprocessing.current_process()
                    ##print 'pid: ',os.getpid()
                    #multiprocessing.current_process().join()
                    if result != wx.ID_YES:
                        event.Veto()
                        return
                    

            except:
                data = StringIO()
                print_exc(file = data)
                sys.stderr.write(data.getvalue())
                pass
        if hasattr(self.utility, 'channelframe'):
            self.utility.channelframe.DestorySelf()
        if hasattr(self.utility, 'packetframe'):
            self.utility.packetframe.DestorySelf()
        if hasattr(self.utility.queue.addtorrents, "busy"):
                del self.utility.queue.addtorrents.busy
        if hasattr(self.utility.signdialog, "busy"):
                del self.utility.signdialog.busy
        self.utility.abcquitting = True
        self.GUIupdate = False
        try:
            self.utility.queue.clearScheduler()
            
        except:
            data = StringIO()
            print_exc(file = data)
            sys.stderr.write(data.getvalue())
            pass

        try:
            self.onTaskBarActivate()
            self.saveWindowSettings()
        except:
            data = StringIO()
            print_exc(file = data)
            sys.stderr.write(data.getvalue())
            pass
        
        try:
            if self.tbicon is not None:
                self.tbicon.RemoveIcon()
                self.tbicon.Destroy()
            #self.Destroy()
            #self.Close()
        except:
            data = StringIO()
            print_exc(file = data)
            sys.stderr.write(data.getvalue())
            pass
        self.utility.frame.Destroy()
        #self.utility.app.OnExit()
        #print 'frame Destroy'
##############################################################
#
# Class : ABCApp
#
# Main ABC application class that contains ABCFrame Object
#
##############################################################
class ABCApp(wx.App):
        
    def __init__(self, x, params, single_instance_checker, abcpath):
        self.params = params
        self.single_instance_checker = single_instance_checker
        self.abcpath = abcpath
        self.ip = get_ip()
        # Set locale to determine localisation
        locale.setlocale(locale.LC_ALL, '')
        
        wx.App.__init__(self, x)
        
        self.Bind(wx.EVT_ACTIVATE_APP, self.OnActivate)
        
    def OnInit(self):

        #print 'ABCApp OnInit'
        self.utility = Utility(self.abcpath)
        self.utility.app = self
        self.utility.queue  = ABCScheduler(self.utility)
        import platform
        iconPath = os.path.join(self.abcpath, 'icon_abc.ico')
        if platform.system()=='Darwin':
            self.utility.icon = wx.Icon(iconPath, wx.BITMAP_TYPE_ICO)
        else:
            self.utility.icon = wx.Icon(iconPath.decode("gbk"), wx.BITMAP_TYPE_ICO)
        self.utility.postAppInit()
        self.utility.encoding = 'utf-8'
        #如果是官网设置ip
#         if self.utility.versionName == "guanwang":
#             self.ip='192.168.138.108'
        loginFrame = self.utility.queue.initLogin()        
        
        #if len(self.ip) < 1:
        if os.path.exists('ipconf') == False and (self.utility.versionName=="qiye" or self.utility.box2):
            ipFrame= self.utility.queue.initIp(loginFrame)
            ipFrame.Show()
            
            
        else:
            loginFrame.Show()
            
        self.utility.go_foreground()
        
        rq = Thread(target = self.storeChannel)
        rq.setDaemon(True)
        rq.start()
        
        return True   
        
    

    def MacReopenApp(self):
        self.BringWindowToFront()
        
    def OnActivate(self, evt):
        # if this is an activate event, rather than something else, like iconize.
        if evt.GetActive():
            self.BringWindowToFront()
        evt.Skip()

    def BringWindowToFront(self):
        try: # it's possible for this event to come when the frame is closed
            if self.utility.showframe == self.utility.details:
                self.utility.parentFrame.Raise()
                self.utility.showframe = self.utility.parentFrame
            elif self.utility.showframe == self.utility.parentFrame and hasattr(self.utility, "details"):
                self.utility.details.Raise()
                self.utility.showframe = self.utility.details
            else:
                self.utility.showframe.Raise()
            
            #self.GetTopWindow().Raise()
        except:
            pass
        
    def MacNewFile(self):
        pass
    
    def MacPrintFile(self, file_path):
        pass
         

    def storeChannel(self):     
        import httplib ,controller
        import HttpUtil
        url = controller.IP() + '/channel'
        response =HttpUtil.http_get(url)
        if response:
            self.utility.config.Write('channel',response)

    def OnExit(self):
        del self.single_instance_checker
        #ClientPassParam("Close Connection")
        self.Destroy()
        return 0

##############################################################
#
# Main Program Start Here
#
##############################################################

def get_ip():
    if os.path.exists('ipconf'):
        f = open('ipconf', 'r')
        ip = f.read()
        f.close()
        return ip
    else:
        return ''

def run(params = None):  
    if params is None:
        params = [""]
    
    if len(sys.argv) > 1:
        params = sys.argv[1:]
    
    # Create single instance semaphore
    single_instance_checker = wx.SingleInstanceChecker("pingpong-abc" + wx.GetUserId())
    
    
    #if single_instance_checker.IsAnotherRunning():
        ##Send  torrent info to abc single instance
        #ClientPassParam(params[0])
    #else:
    abcpath = os.path.abspath(os.path.dirname(sys.argv[0]))
    os.chdir(abcpath)
    ##print 'abcpath',abcpath
    
    app = ABCApp(0, params, single_instance_checker, abcpath)
    app.MainLoop()            

if __name__ == '__main__':
    run()
